---
name: action-item-to-jira
description: 把已經結構化的 Action Item(Owner/Action/Due Date/Priority)透過 Jira REST API 建立對應的 Jira 票,並避免對同一個 Action Item 重複建票。是「把待辦事項寫入 Jira」,不是從逐字稿整理會議摘要與待辦事項(那是 meeting-summary)。當使用者已經有結構化的 Action Item 清單,並要求「建 Jira 票」「同步到 Jira」「開票追蹤這些待辦」時使用。關鍵詞:Jira、建票、issue、ticket、同步待辦。
disable-model-invocation: true   # 只能手動 /action-item-to-jira 呼叫,不會被自動語意觸發——
                                  # 這是有寫入副作用的 Skill 的標準做法,不只靠 description 防呆
user-invocable: true
version: 0.2.0
---
# Action Item → Jira Ticket Skill(Wrap Existing Tools 範例)

## ① 適用範圍 / 不適用時改用
- 適用:使用者已經有結構化的 Action Item 清單(表格或清單形式),並要求把這些項目建立成 Jira 票。
- 不適用:Action Item 還沒被整理成結構化資料 → 先用 `meeting-summary` 把逐字稿整理成含 Action Items 的會議紀錄,這個 Skill 只負責「已經結構化的資料 → Jira」這一段。
- 不適用:使用者只是想「看看」逐字稿中的待辦事項有哪些,沒有明確要求寫入 Jira → 改用 `meeting-summary`,不要自作主張連建票都做了。
- 不適用:找不到 Owner 對照表、或 Jira 端點設定缺漏時,不要用姓名字串硬塞 assignee 蒙混過去,誠實回報設定缺漏。

> 這個界線本身就是 M2 教過的 Scope 拆分原則:「一句話講不完的事,拆成多個 Skill」。「從逐字稿抽取待辦,而且順便建 Jira 票」一句話講不完,而且兩者的工具/寫入權限邊界完全不同——抽取只讀逐字稿,建票要寫入外部系統、要額外的 API 認證——所以拆成兩個 Skill,各自的輸入輸出邊界清楚。

## ② 需要的輸入
1. 結構化 Action Item 清單(必要):Owner / Action / Due Date / Priority。
2. Jira 專案代碼(必要),例如 `MIP`。
3. **Owner 姓名 → Jira 帳號的對照表**(必要)。姓名沒辦法直接拿去指派,Jira 需要明確的帳號識別(email 或 accountId)。**沒有對照表時,先反問,不要用姓名字串直接硬塞進 assignee 欄位。**
4. Jira base URL 與認證資訊——一律透過環境變數提供(例如 `JIRA_API_TOKEN`),**絕不寫進 Skill 定義、輸出內容、或對話紀錄裡**。呼叫 API 時帶入 `Authorization: Bearer {token}` header。若收到 401,視為「認證設定缺漏」,誠實回報,不要重試硬闖、不要把 token 值印出來 debug。

## ③ 步驟(優先包既有工具/API,不要純手寫邏輯)

> base URL 與認證 token 取自 ②-4 的環境變數或使用者提供值,本區塊只處理呼叫順序與參數邏輯,不重複交代環境設定。

1. 對每一筆 Action Item,先呼叫 Jira 的搜尋 API(`GET /rest/api/2/search?jql=...`),用 summary 關鍵字比對是否已經存在相同任務的票——**避免重複建票**。
2. 若不存在,呼叫 `POST /rest/api/2/issue` 建立新票:
   - `summary` = Action 內容
   - `assignee` = 對照表查到的帳號(查不到就標記失敗,不用姓名硬塞)
   - `duedate` = Due Date(若「未訂」則不帶這個欄位,不要塞假日期)
   - `priority` = 依 Priority 對照 Jira 的 priority scheme
3. 若已存在,略過並在輸出裡註明「已存在,略過」。
4. 全部處理完後,依 ④ 的格式輸出對照表。

## ④ 輸出格式

```markdown
## Jira 同步結果

| Owner | Action | Jira Ticket | 狀態 |
|---|---|---|---|
| <姓名> | <任務內容> | <MIP-101 或「—」> | <新建 / 已存在,略過 / 失敗:原因> |
```

## ⑤ 品質自檢(產出後逐項確認,沒過就修再交)
- [ ] 每一筆都有對應到 Jira 帳號;沒有帳號對照的項目明確列為「失敗:找不到 Jira 帳號」,**不用姓名字串硬塞進 assignee**。
- [ ] 執行前有先查詢是否已存在相同票,**避免重複建立**。
- [ ] Due Date 為「未訂」的項目沒有被塞入自己編造的假日期。
- [ ] 認證資訊(token / API key)**沒有出現**在輸出、log 或對話紀錄裡。
- [ ] 認證失敗(401)時,Skill 誠實回報「無法連線/認證失敗」,不把 token 值(不論對錯)印在輸出或 log 裡除錯。
- [ ] 每一筆都有明確狀態(新建/已存在/失敗),沒有靜默失敗、沒有被忽略不報告的項目。

## 為什麼這個 Skill 值得特別小心

前面 M2、M3 的 Skill 就算會呼叫外部工具(例如 `weekly-followup-planner` 呼叫 CalendarTools MCP),也都是**唯讀**——做錯了頂多是「讀到的資訊不準」,使用者自己會發現;**這個 Skill 會真的對外部系統寫入資料(建立 Jira 票)**,如果重複建票、指派錯人、或塞了假期限,造成的是團隊實際工作流程的混亂,而且不一定會被立刻發現。這正是它要設定 `disable-model-invocation: true` 的原因——唯讀的 Skill 可以放心讓 Copilot 自動語意選中,寫入型的 Skill 不行,必須使用者明確打 `/action-item-to-jira` 才會執行。這也是下一個模組(M6)要談的:**這類「會寫入外部系統」的 Skill,上線前該不該有人先看過一次?**
