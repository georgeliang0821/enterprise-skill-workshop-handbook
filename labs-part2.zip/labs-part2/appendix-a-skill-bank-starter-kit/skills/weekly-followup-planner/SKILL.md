---
name: weekly-followup-planner
description: 依使用者本週行事曆的空檔,搭配內部 Action Item 記錄裡尚未結案的項目,產生一份「本週跟進規劃」——哪些時段有空、有哪些未結事項可以排進去處理。是「用空檔安排跟進未結事項」,不是逐字稿摘要(那是 meeting-summary),也不是專案範圍分解(那是 wbs-generator)。關鍵詞:本週空檔、有空、跟進、排時間、未結事項、weekly followup、free slot、availability。
disable-model-invocation: false
user-invocable: true
version: 0.3.0
---
# 本週跟進規劃 Skill(Weekly Follow-up Planner)

## ① 適用範圍 / 不適用時改用
- 適用:使用者想知道「本週哪些時段有空」,並把還沒結案的待辦排進去跟進,或問「這週我可以找時間處理哪些未結事項」。
- 不適用:會議已經結束、有逐字稿需要整理 → 改用 `meeting-summary`。
- 不適用:使用者要的是專案範圍拆解 → 改用 `wbs-generator`。
- 不適用:讀不到行事曆(沒有 CalendarTools 存取權、使用者也沒提供替代行事曆資料或「假設有空」的指示)時,不要憑空編造空檔,誠實回報「查不到行事曆資料」並反問。

## ② 需要的輸入
1. 行事曆來源(必要):透過 CalendarTools 讀取本週行事曆算出空檔;沒有存取權時,由使用者提供替代資料(`data/sample-calendar-week.json`),或明確指示「假設本週某些時段都有空」。
2. Action Item 記錄來源(必要):團隊實際的 Action Item store,Lab 環境用 `data/past-action-items.json` 模擬——這份記錄可以是 `meeting-summary` 過去產出的 Action Items 累積下來的結果。
3. 時間範圍(選,預設為「本週」)。

> 這是一個**多來源整合**的 Skill:空檔來自行事曆(CalendarTools),未結事項來自內部 Action Item 記錄——兩個來源各自獨立,不需要互相對齊,但輸出的每一條都必須能標回它是從哪一個來源來的。

## ③ 步驟
1. 呼叫 CalendarTools(或讀取使用者提供的 `sample-calendar-week.json`,或依使用者指示的「假設有空」)取得本週各時段的忙碌與空檔。
2. 完全讀不到任何行事曆資料、使用者也沒給替代資料或假設時,誠實回報並反問,**不要**自己編出空檔。
3. 讀 Action Item 記錄,取出所有 `status` 為 `open` 的項目——**已經 `done` 的項目不要列入**。
4. 把未結事項對應到本週的空檔給出跟進建議;空檔不足以塞下所有事項時,如實說明,不要硬塞或假裝排得下。
5. 依 ④ 的格式整理輸出,行事曆空檔與未結事項**各自標明來源**。

## ④ 輸出格式

```markdown
## 本週跟進規劃(<本週日期範圍>)

### 可用空檔
- <星期 X> <start>-<end>——來源:calendar
...
(本週完全沒有空檔時寫「本週無可用空檔」)

### 待跟進的未結事項
- <owner>:<action>(due: <dueDate 或「未訂」>)——來源:<action item id>
...
(沒有未結事項時寫「無未結事項」)

### 建議排程
- 把「<action 摘要>」排在 <星期 X> <start>-<end>——依據:<action item id> + 該空檔
...
(空檔或未結事項任一為空時,說明無法給出建議的原因,不硬湊)
```

## ⑤ 品質自檢(產出後逐項確認,沒過就修再交)
- [ ] 每一條「待跟進的未結事項」都標明來源(哪一筆 Action Item 記錄 id),沒有臆測。
- [ ] 只列出 `status: open` 的項目,沒有把 `done` 的項目也列進去。
- [ ] 「可用空檔」只反映行事曆真實內容(或使用者明確提供/指示的假設),沒有自己腦補不存在的空檔。
- [ ] 讀不到行事曆資料時,有誠實回報並反問,不是硬生一份規劃。
- [ ] 沒有空檔或沒有未結事項時,明確寫「本週無可用空檔」/「無未結事項」,不是省略整個區塊。

## 這個 Skill 跟其他 Skill 的差異

`meeting-summary` 只讀「使用者當場提供的逐字稿」,是單一來源;`wbs-generator` 也是單一來源,但多了一段 code execution 才能落地成 Excel 檔案。`weekly-followup-planner` 是第一個**多來源工具整合**的 Skill:先呼叫 MCP(CalendarTools)拿到本週空檔,再查內部資料(Action Item 記錄)拿到未結事項,最後整合成跟進規劃——工具鏈變長,風險也從「幻覺一個不存在的命中結果」升級成「幻覺一個不存在的空檔或事項」,錯誤可能來自任何一個環節。這也是為什麼 ⑤ 品質自檢最重要的一條,是「每一條都要能標回來源」。
